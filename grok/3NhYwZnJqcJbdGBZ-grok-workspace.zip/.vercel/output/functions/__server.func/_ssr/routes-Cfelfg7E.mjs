import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Store, c as Salad, d as IceCreamBowl, f as Flame, g as ChevronLeft, h as ChevronRight, l as Leaf, m as Clock, n as Wheat, o as Soup, p as Coffee, r as UtensilsCrossed, s as Search, t as X, u as Info } from "../_libs/lucide-react.mjs";
import { l as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cfelfg7E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatPrice(price) {
	if (price === null) return "MRP";
	return `₹ ${price}`;
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("shrink-0", className),
		role: "img",
		"aria-label": "Kailash",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "6",
			fill: "#8B1A1A"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "16",
			y: "23",
			textAnchor: "middle",
			fill: "#FBF6EC",
			fontFamily: "Georgia, serif",
			fontSize: "18",
			fontWeight: "700",
			children: "K"
		})]
	});
}
function LogoPlate({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 160 160",
		className: cn("shrink-0", className),
		role: "img",
		"aria-label": "Kailash Veg Restaurant",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "160",
				height: "160",
				rx: "8",
				fill: "#8B1A1A"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "8",
				width: "144",
				height: "144",
				rx: "4",
				fill: "none",
				stroke: "#F3E8D4",
				strokeWidth: "1",
				opacity: "0.28"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				transform: "translate(118 16)",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "22",
						height: "5",
						fill: "#FF9933"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						y: "5",
						width: "22",
						height: "5",
						fill: "#FFFFFF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						y: "10",
						width: "22",
						height: "5",
						fill: "#138808"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "11",
						cy: "7.5",
						r: "1.6",
						fill: "#000080"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "80",
				y: "78",
				textAnchor: "middle",
				fill: "#FBF6EC",
				fontFamily: "'Great Vibes', cursive",
				fontSize: "48",
				children: "Kailash"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "80",
				y: "104",
				textAnchor: "middle",
				fill: "#FBF6EC",
				fontFamily: "'Cormorant Garamond', Georgia, serif",
				fontSize: "11",
				letterSpacing: "2.6",
				children: "VEG RESTAURANT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "80",
				y: "124",
				textAnchor: "middle",
				fill: "#F3E8D4",
				fontFamily: "'Outfit', sans-serif",
				fontSize: "7.5",
				opacity: "0.85",
				children: "Unit of Hotel NANDANVAN Pvt. Ltd."
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,color,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:bg-primary/90",
			ghost: "text-fg hover:bg-fg/5",
			outline: "bg-surface text-fg shadow-[var(--shadow-border)] hover:bg-fg/5"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-surface px-3 text-base text-fg shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 placeholder:text-ink-soft focus-visible:ring-2 focus-visible:ring-primary/35", className),
		...props
	});
}
var RESTAURANT = {
	name: "Kailash",
	tagline: "VEG RESTAURANT",
	unit: "Unit of Hotel NANDANVAN Pvt. Ltd.",
	gst: "9% GST Extra On Bill Amount",
	lunch: "11am – 4pm",
	dinner: "7pm – 11pm",
	oil: "All food are prepared in Sunflower Refine Oil & Pure Ghee",
	water: "Safe Drinking (Potable) Water is available free of charge",
	outside: "Outside Food Not Allowed",
	smoking: "No Smoking · Take Care of your belongings",
	marathi: "आम्ही आमच्या संस्थामधे पीज गॅसलां वापरत नाही. आम्ही तुपापासून बनवलेल्या मसाले फक्त वापर करतो.",
	msg: "Ajinomoto (MSG) is used in some cuisine. Not recommended for infants below 12 months and pregnant women."
};
var LUNCH_BOX = {
	name: "Carry Lunch Box",
	price: 320,
	includes: "2 Veg. 3 Chapati, Rice, Sweet, 1 Dal, 1 Papad"
};
var CHAPTERS = [
	{
		id: "south-indian",
		title: "South Indian",
		kicker: "Snacks, uttapa & dosa",
		icon: "south",
		subsections: [
			{
				name: "South Indian Snacks",
				items: [
					{
						name: "Upama",
						price: 66
					},
					{
						name: "Sheera",
						price: 77
					},
					{
						name: "Steam Idli",
						price: 66
					},
					{
						name: "Fried Idli",
						price: 83
					},
					{
						name: "Dahi Idli",
						price: 109
					},
					{
						name: "Butter Idli",
						price: 97
					},
					{
						name: "Idli Vada",
						price: 88
					},
					{
						name: "Medu Vada",
						price: 88
					},
					{
						name: "Dahi Vada",
						price: 109
					},
					{
						name: "Cutlet",
						price: 83
					},
					{
						name: "Cutlet With Chole",
						price: 143
					},
					{
						name: "Finger Chips",
						price: 143
					},
					{
						name: "Sabudana Vada",
						price: 88
					},
					{
						name: "Potato Vada",
						price: 66
					},
					{
						name: "Sweet Kachori",
						price: 109
					},
					{
						name: "Sabudana Khichdi",
						price: 105
					}
				]
			},
			{
				name: "Uttapa",
				items: [
					{
						name: "Onion Uttapa",
						price: 99
					},
					{
						name: "Coconut Uttapa",
						price: 99
					},
					{
						name: "Tomato Uttapa",
						price: 99
					},
					{
						name: "Masala Uttapa",
						price: 132
					},
					{
						name: "Special Uttapa",
						price: 149
					},
					{
						name: "Cheese Uttapa",
						price: 160
					},
					{
						name: "Tomato Omlet",
						price: 109
					},
					{
						name: "Banana Uttapa",
						price: 109
					},
					{
						name: "Butter Onion Uttapa",
						price: 116
					},
					{
						name: "Butter Plain Uttapa",
						price: 105
					},
					{
						name: "Tomato Onion Uttapa",
						price: 116
					},
					{
						name: "Spring Masala Uttapa",
						price: 149
					},
					{
						name: "Veg. Uttapa",
						price: 149
					}
				]
			},
			{
				name: "Kailash Special 4 Feet Dosa",
				items: [{
					name: "Sada Dosa",
					price: 429,
					tag: "signature"
				}, {
					name: "Masala Dosa",
					price: 468,
					tag: "signature"
				}]
			},
			{
				name: "Dosa",
				items: [
					{
						name: "Sada Dosa",
						price: 88
					},
					{
						name: "Masala Dosa",
						price: 103
					},
					{
						name: "Palak Sada Dosa",
						price: 105
					},
					{
						name: "Palak Masala",
						price: 127
					},
					{
						name: "Mysore Sada Dosa",
						price: 121
					},
					{
						name: "Mysore Masala Dosa",
						price: 138
					},
					{
						name: "Kailash Special Dosa",
						price: 149,
						tag: "signature"
					},
					{
						name: "Cheese Masala Dosa",
						price: 182
					},
					{
						name: "Set Dosa",
						price: 121
					},
					{
						name: "Dosa Tokri",
						price: 358
					},
					{
						name: "Cheese Sada Dosa",
						price: 149
					},
					{
						name: "Onion Rawa Dosa",
						price: 127
					},
					{
						name: "Onion Rawa Sada Dosa",
						price: 116
					},
					{
						name: "Onion Rawa Masala Dosa",
						price: 127
					},
					{
						name: "Rawa Masala Dosa",
						price: 116
					},
					{
						name: "Rawa Sada Dosa",
						price: 116
					},
					{
						name: "Butter Sada Dosa",
						price: 99
					},
					{
						name: "Butter Masala Dosa",
						price: 127
					},
					{
						name: "Extra Sambar / Chutney",
						price: 11,
						tag: "extra"
					},
					{
						name: "Extra Aloo Bhaji",
						price: 11,
						tag: "extra"
					},
					{
						name: "Extra Cheese",
						price: 66,
						tag: "extra"
					}
				]
			},
			{
				name: "Special Dosa",
				items: [
					{
						name: "Paneer Chilli Dosa",
						price: 292
					},
					{
						name: "Veg. Masala Dosa",
						price: 182
					},
					{
						name: "Paneer Schezwan Dosa",
						price: 303
					},
					{
						name: "Veg. Noodle Dosa",
						price: 231
					},
					{
						name: "Veg. Schez. Noodles Dosa",
						price: 248
					},
					{
						name: "Paneer Chilli Rawa Dosa",
						price: 303
					},
					{
						name: "Paneer Schez. Rawa Dosa",
						price: 314
					},
					{
						name: "Veg. Noodle Rawa Dosa",
						price: 292
					},
					{
						name: "Scz. Noodle Rawa Dosa",
						price: 314
					},
					{
						name: "Spring Dosa",
						price: 160
					}
				]
			}
		]
	},
	{
		id: "street",
		title: "Street Favourites",
		kicker: "Chat, sandwich, pav bhaji & pizza",
		icon: "street",
		subsections: [
			{
				name: "Chat",
				items: [
					{
						name: "Pani Puri",
						price: 109
					},
					{
						name: "Bombay Bhel",
						price: 109
					},
					{
						name: "Special Bhel",
						price: 121
					},
					{
						name: "Shev Puri",
						price: 121
					},
					{
						name: "Dahi Shev Puri",
						price: 132
					}
				]
			},
			{
				name: "Sandwich",
				items: [
					{
						name: "Veg Sandwich",
						price: 94
					},
					{
						name: "Cheese Sandwich",
						price: 116
					},
					{
						name: "Cheese Veg Sandwich",
						price: 138
					},
					{
						name: "Veg. Toast Sandwich",
						price: 149
					},
					{
						name: "Veg Grill Sandwich",
						price: 160
					},
					{
						name: "Veg Cheese Grill Sandwich",
						price: 187
					},
					{
						name: "Cheese Grill Sandwich",
						price: 176
					},
					{
						name: "Cheese Chilli Grill Sandwich",
						price: 215
					},
					{
						name: "Jam Sandwich",
						price: 77
					},
					{
						name: "Bread Butter Toast",
						price: 88
					},
					{
						name: "Butter Cheese Toast",
						price: 138
					},
					{
						name: "Chutney Sandwich",
						price: 83
					},
					{
						name: "Tomato Omelet Toast S/w",
						price: 160
					},
					{
						name: "Butter Jam",
						price: 99
					}
				]
			},
			{
				name: "Pav Bhaji",
				items: [
					{
						name: "Sada Pav Bhaji",
						price: 121
					},
					{
						name: "Bombay Pav Bhaji",
						price: 149
					},
					{
						name: "Jain Pav Bhaji",
						price: 121
					},
					{
						name: "Paneer Pav Bhaji",
						price: 149
					},
					{
						name: "Special Pav Bhaji",
						price: 160
					},
					{
						name: "Khada Pav Bhaji",
						price: 143
					},
					{
						name: "Cheese Pav Bhaji",
						price: 182
					},
					{
						name: "Extra Pav with Butter (2 pcs)",
						price: 28,
						tag: "extra"
					},
					{
						name: "Masala Pav (2 pcs)",
						price: 132
					},
					{
						name: "Extra Bhaji",
						price: 99,
						tag: "extra"
					},
					{
						name: "Tawa Pulav",
						price: 231
					}
				]
			},
			{
				name: "Pizza",
				items: [
					{
						name: "Cheese Pizza",
						price: 270
					},
					{
						name: "Capsicum Pizza",
						price: 270
					},
					{
						name: "Tomato Pizza",
						price: 270
					},
					{
						name: "Mix Veg. Pizza",
						price: 297
					},
					{
						name: "Cheese Paneer Pizza",
						price: 308
					},
					{
						name: "Veg. Special Pizza",
						price: 319
					}
				]
			}
		]
	},
	{
		id: "punjabi",
		title: "Punjabi Kitchen",
		kicker: "Gravies, paneer, dal & kofta",
		icon: "punjabi",
		subsections: [
			{
				name: "Paneer",
				items: [
					{
						name: "Paneer Butter Masala",
						price: 314
					},
					{
						name: "Paneer Tikka Masala",
						price: 347
					},
					{
						name: "Mutter Paneer",
						price: 303
					},
					{
						name: "Paneer Bhurji",
						price: 292
					},
					{
						name: "Paneer Tikka Lababdar",
						price: 358
					},
					{
						name: "Paneer Lasuni M/S",
						price: 325
					},
					{
						name: "Paneer Maratha",
						price: 314
					},
					{
						name: "Paneer Pasanda",
						price: 347
					},
					{
						name: "Paneer Shahi Kurma",
						price: 314
					},
					{
						name: "Kadhai Paneer",
						price: 341
					},
					{
						name: "Paneer Tawa Masala",
						price: 314
					},
					{
						name: "Paneer Handi",
						price: 341
					},
					{
						name: "Paneer Palak",
						price: 292
					},
					{
						name: "Paneer Kheema Masala",
						price: 325
					},
					{
						name: "Kaju Paneer Masala",
						price: 347
					}
				]
			},
			{
				name: "Dal",
				items: [
					{
						name: "Chole Batura",
						price: 231
					},
					{
						name: "Extra Batura",
						price: 72,
						tag: "extra"
					},
					{
						name: "Dal Fry",
						price: 176
					},
					{
						name: "Dal Tadka",
						price: 193
					},
					{
						name: "Dal Kolhapuri",
						price: 193
					},
					{
						name: "Dal Makhani",
						price: 270
					},
					{
						name: "Dal Jaffrezi",
						price: 308
					},
					{
						name: "Rajma Masala",
						price: 264
					}
				]
			},
			{
				name: "Kofta",
				items: [
					{
						name: "Malai Kofta",
						price: 308
					},
					{
						name: "Cheese Kofta",
						price: 352
					},
					{
						name: "Veg. Kofta",
						price: 303
					},
					{
						name: "Veg. Kashmiri Kofta",
						price: 325
					}
				]
			},
			{
				name: "Palak, Methi & Kaju",
				items: [
					{
						name: "Plain Palak",
						price: 231
					},
					{
						name: "Mushroom Palak",
						price: 325
					},
					{
						name: "Aloo Palak",
						price: 231
					},
					{
						name: "Methi Mutter Malai",
						price: 319
					},
					{
						name: "Aloo Methi",
						price: 215
					},
					{
						name: "Methi Lasuni",
						price: 226
					},
					{
						name: "Methi Lasuni Masala",
						price: 270
					},
					{
						name: "Kaju Mutter",
						price: 336
					},
					{
						name: "Kaju Curry",
						price: 358
					}
				]
			},
			{
				name: "Vegetable Gravies",
				items: [
					{
						name: "Green Peas Aloo Masala",
						price: 231
					},
					{
						name: "Green Peas Masala",
						price: 231
					},
					{
						name: "Mushroom Masala",
						price: 314
					},
					{
						name: "Babycorn Masala",
						price: 314
					},
					{
						name: "Veg. Maratha",
						price: 303
					},
					{
						name: "Jeera Aloo",
						price: 171
					},
					{
						name: "Chana Masala",
						price: 231
					},
					{
						name: "Baigan Masala",
						price: 231
					},
					{
						name: "Baigan Bharta",
						price: 231
					},
					{
						name: "Drumstick Masala",
						price: 281
					},
					{
						name: "Shevbhaji Masala",
						price: 231
					},
					{
						name: "Bhendi Masala fry",
						price: 231
					},
					{
						name: "Karela Masala",
						price: 231
					},
					{
						name: "Capsicum Masala",
						price: 226
					},
					{
						name: "Stuff Capsicum",
						price: 226
					},
					{
						name: "Tomato Bharta",
						price: 215
					},
					{
						name: "Stuff Tomato",
						price: 215
					},
					{
						name: "Veg Handi",
						price: 314
					},
					{
						name: "Veg. Kadhai",
						price: 314
					},
					{
						name: "Veg. Tawa",
						price: 308
					},
					{
						name: "Veg. Bhoona",
						price: 308
					},
					{
						name: "Veg. Maharaja",
						price: 325
					},
					{
						name: "Veg Makhanwala",
						price: 292
					},
					{
						name: "Veg. Kabab Curry",
						price: 308
					},
					{
						name: "Veg. Aloo Gobi",
						price: 231
					},
					{
						name: "Veg. Liver Masala",
						price: 303
					},
					{
						name: "Veg. Angoori",
						price: 308
					},
					{
						name: "Veg. Jaipuri",
						price: 308
					},
					{
						name: "Navratan Kurma",
						price: 325
					},
					{
						name: "Dum Aloo Kashmiri",
						price: 297
					},
					{
						name: "Veg. Chatpata",
						price: 297
					},
					{
						name: "Kailash Special Veg",
						price: 352,
						tag: "signature"
					},
					{
						name: "Baigan Tikka",
						price: 281
					},
					{
						name: "Cheese Angoori",
						price: 347
					},
					{
						name: "Veg Kheema Masala",
						price: 281
					},
					{
						name: "Veg. Kolhapuri",
						price: 314
					},
					{
						name: "Veg. Pattyala",
						price: 325
					},
					{
						name: "Veg. Dhwani Handi",
						price: 308
					},
					{
						name: "Hyderabadi Kurma",
						price: 308
					},
					{
						name: "Veg Kurma",
						price: 308
					},
					{
						name: "Veg. Afghani",
						price: 341
					},
					{
						name: "Mix Vegitable",
						price: 286
					},
					{
						name: "Mushroom Tikka Masala",
						price: 352
					},
					{
						name: "Mushroom Kolhapuri",
						price: 361
					}
				]
			}
		]
	},
	{
		id: "chinese",
		title: "Chinese",
		kicker: "Soups, starters, gravy & noodles",
		icon: "chinese",
		subsections: [
			{
				name: "Chinese Soups",
				items: [
					{
						name: "Sweet Corn Plain Soup",
						price: 116
					},
					{
						name: "Sweet Corn Veg. Soup",
						price: 132
					},
					{
						name: "Hot & Sour Soup",
						price: 132
					},
					{
						name: "Manchow Soup",
						price: 143
					},
					{
						name: "Mushroom Soup",
						price: 154
					},
					{
						name: "Veg. Noodle Soup",
						price: 154
					},
					{
						name: "Green Peas Soup",
						price: 138
					},
					{
						name: "Cream Of Palak Soup",
						price: 149
					},
					{
						name: "Tomato Soup",
						price: 116
					},
					{
						name: "Cream Of Veg. Soup",
						price: 149
					},
					{
						name: "Veg. Clear Soup",
						price: 94
					}
				]
			},
			{
				name: "Starters",
				items: [
					{
						name: "Chinese Bhel",
						price: 204
					},
					{
						name: "Veg. Spring Roll",
						price: 281
					},
					{
						name: "Veg. Lolly pop",
						price: 281
					},
					{
						name: "Veg. Ball Schezwan Dry",
						price: 303
					},
					{
						name: "Cheese Ball Schezwan",
						price: 352
					},
					{
						name: "Veg. Gold Coin",
						price: 215
					},
					{
						name: "Veg. Gold Finger",
						price: 215
					},
					{
						name: "Veg. Crispy Dry",
						price: 325
					},
					{
						name: "Veg. Prem Roll",
						price: 341
					},
					{
						name: "Baby Corn Chilli",
						price: 325
					},
					{
						name: "Paneer Chilli Dry",
						price: 325
					},
					{
						name: "Paneer Kentucky",
						price: 325
					},
					{
						name: "Gobi Kentucky",
						price: 314
					},
					{
						name: "Baby Corn Kentucky",
						price: 341
					},
					{
						name: "Mushroom Kentucky",
						price: 363
					},
					{
						name: "Cheese Pakoda",
						price: 363
					},
					{
						name: "Paneer Pakoda",
						price: 308
					}
				]
			},
			{
				name: "Manchurian",
				items: [
					{
						name: "Veg. Manchurian",
						price: 281
					},
					{
						name: "Veg. Garlic",
						price: 292
					},
					{
						name: "Veg. Schezwan",
						price: 292
					},
					{
						name: "Mushroom Manchurian",
						price: 341
					},
					{
						name: "Paneer Manchurian",
						price: 325
					},
					{
						name: "Idli Manchurian",
						price: 286
					},
					{
						name: "Gobi Manchurian",
						price: 281
					}
				]
			},
			{
				name: "Chillis",
				items: [
					{
						name: "Paneer Chilli",
						price: 325
					},
					{
						name: "Veg. Chilli",
						price: 303
					},
					{
						name: "Mushroom Chilli",
						price: 341
					},
					{
						name: "Idli Chilli",
						price: 308
					},
					{
						name: "Paneer 65",
						price: 325
					},
					{
						name: "Veg. 65",
						price: 308
					},
					{
						name: "Veg. Hong Kong",
						price: 308
					},
					{
						name: "Paneer Hong Kong",
						price: 341
					}
				]
			},
			{
				name: "Rice & Noodles",
				items: [
					{
						name: "Veg. Fried Rice",
						price: 270
					},
					{
						name: "Mushroom Fried Rice",
						price: 303
					},
					{
						name: "Onion Fried Rice",
						price: 259
					},
					{
						name: "Jeera Fried Rice",
						price: 242
					},
					{
						name: "Singapore Fried Rice",
						price: 303
					},
					{
						name: "Schezwan Fried Rice",
						price: 314
					},
					{
						name: "Triple Schezwan Fried Rice",
						price: 341
					},
					{
						name: "Veg. Noodles",
						price: 237
					},
					{
						name: "Noodle Fried Rice",
						price: 308
					},
					{
						name: "Schezwan Noodle Fried Rice",
						price: 325
					},
					{
						name: "Veg. Schezwan Noodle",
						price: 292
					},
					{
						name: "Veg. Singapore Noodle",
						price: 292
					},
					{
						name: "Veg. American Choupsay",
						price: 314
					}
				]
			}
		]
	},
	{
		id: "tandoor",
		title: "Tandoor",
		kicker: "Kabab & tikka",
		icon: "tandoor",
		subsections: [{
			name: "Kabab",
			items: [
				{
					name: "Paneer Tikka",
					price: 352
				},
				{
					name: "Dry Tandoori Gobi",
					price: 325
				},
				{
					name: "Veg. Sheekh Kabab",
					price: 325
				},
				{
					name: "Veg. Harabhara Kabab",
					price: 259
				},
				{
					name: "Mushroom Tikka",
					price: 363
				}
			]
		}]
	},
	{
		id: "rice",
		title: "Rice",
		kicker: "Biryani, pulav & khichdi",
		icon: "rice",
		subsections: [{
			name: "Rice",
			items: [
				{
					name: "Veg. Biryani",
					price: 231
				},
				{
					name: "Paneer Tikka Biryani",
					price: 259
				},
				{
					name: "Veg. Handi Biryani",
					price: 248
				},
				{
					name: "Veg. Hyderabadi Biryani",
					price: 237
				},
				{
					name: "Veg. Dum Biryani",
					price: 281
				},
				{
					name: "Veg. Pulav",
					price: 215
				},
				{
					name: "Steam Rice",
					price: 171
				},
				{
					name: "Jeera Rice",
					price: 182
				},
				{
					name: "Kashmiri Pulav",
					price: 292
				},
				{
					name: "Green Peas Pulav",
					price: 215
				},
				{
					name: "Palak Rice",
					price: 215
				},
				{
					name: "Curd Rice",
					price: 215
				},
				{
					name: "Onion Rice",
					price: 215
				},
				{
					name: "Dal Khichdi",
					price: 204
				},
				{
					name: "Tadka Dal Khichdi",
					price: 215
				},
				{
					name: "Paneer Pulav",
					price: 237
				},
				{
					name: "Cheese Pulav",
					price: 303
				}
			]
		}]
	},
	{
		id: "breads",
		title: "Breads",
		kicker: "Roti, nan, paratha & kulcha",
		icon: "breads",
		subsections: [{
			name: "Roti",
			items: [
				{
					name: "Plain Roti",
					price: 24
				},
				{
					name: "Butter Roti",
					price: 31
				},
				{
					name: "Wheat Roti",
					price: 33
				},
				{
					name: "Butter Wheat Roti",
					price: 39
				},
				{
					name: "Methi Roti",
					price: 39
				},
				{
					name: "Nan",
					price: 50
				},
				{
					name: "Butter Nan",
					price: 61
				},
				{
					name: "Plain Paratha",
					price: 50
				},
				{
					name: "Butter Paratha",
					price: 61
				},
				{
					name: "Paneer Paratha",
					price: 171
				},
				{
					name: "Cheese Paratha",
					price: 209
				},
				{
					name: "Kulcha",
					price: 61
				},
				{
					name: "Butter Kulcha",
					price: 72
				},
				{
					name: "PARATHA (Methi, Aloo, Gobi)",
					price: 160
				},
				{
					name: "Kashmiri Nan",
					price: 209
				},
				{
					name: "Garlic Nan",
					price: 94
				},
				{
					name: "Chapati",
					price: 18
				},
				{
					name: "Basket Roti",
					price: 439
				}
			]
		}]
	},
	{
		id: "sides",
		title: "Sides",
		kicker: "Salad, papad & raita",
		icon: "sides",
		subsections: [
			{
				name: "Salad",
				items: [
					{
						name: "Green Salad",
						price: 105
					},
					{
						name: "Tomato Salad",
						price: 88
					},
					{
						name: "Crispy Noodle Salad",
						price: 209
					},
					{
						name: "Chee. Cherry Pineapple Salad",
						price: 308
					}
				]
			},
			{
				name: "Papad",
				items: [
					{
						name: "Roasted Papad",
						price: 22
					},
					{
						name: "Fry Papad",
						price: 33
					},
					{
						name: "Masala Papad",
						price: 50
					}
				]
			},
			{
				name: "Raita",
				items: [
					{
						name: "Mix Raita",
						price: 121
					},
					{
						name: "Fruit Raita",
						price: 132
					},
					{
						name: "Pine Apple Raita",
						price: 132
					},
					{
						name: "Tomato Raita",
						price: 116
					},
					{
						name: "Onion Raita",
						price: 116
					},
					{
						name: "Boondi Raita",
						price: 121
					},
					{
						name: "Aloo Raita",
						price: 116
					},
					{
						name: "Plain Raita",
						price: 105
					}
				]
			}
		]
	},
	{
		id: "drinks",
		title: "Drinks",
		kicker: "Hot drinks, juice, lassi & shakes",
		icon: "drinks",
		subsections: [
			{
				name: "Hot Drink",
				items: [
					{
						name: "Tea",
						price: 33
					},
					{
						name: "Filter Coffee",
						price: 50
					},
					{
						name: "Nes Coffee",
						price: 55
					},
					{
						name: "Bournvita",
						price: 83
					},
					{
						name: "Hot Chocolate",
						price: 83
					}
				]
			},
			{
				name: "Juice",
				items: [
					{
						name: "Mosambi (Sweet-Lime)",
						price: 105
					},
					{
						name: "Orange Juice",
						price: 105
					},
					{
						name: "Ganga Jamuna",
						price: 105
					},
					{
						name: "Mars Mari",
						price: 105
					},
					{
						name: "Cocktail Juice",
						price: 105
					},
					{
						name: "Pineapple Juice",
						price: 105
					},
					{
						name: "Grape Juice",
						price: 138
					},
					{
						name: "Mango Juice",
						price: 116
					},
					{
						name: "Fresh Lime",
						price: 61
					},
					{
						name: "Watermelon",
						price: 105
					}
				]
			},
			{
				name: "Lassi",
				items: [
					{
						name: "Sweet Lassi",
						price: 109
					},
					{
						name: "Mango Lassi",
						price: 138
					},
					{
						name: "Special Lassi",
						price: 182
					},
					{
						name: "Salted Lassi",
						price: 109
					},
					{
						name: "Butter Milk",
						price: 39
					}
				]
			},
			{
				name: "Milk Shake",
				items: [
					{
						name: "Apple Shake",
						price: 215
					},
					{
						name: "Chikoo Shake",
						price: 204
					},
					{
						name: "Anjeer Shake",
						price: 237
					},
					{
						name: "Mix Shake",
						price: 198
					},
					{
						name: "Cold Coffee",
						price: 176
					},
					{
						name: "Chocolate Shake",
						price: 176
					},
					{
						name: "Banana Shake",
						price: 176
					},
					{
						name: "Strawberry Shake",
						price: 204
					},
					{
						name: "Mango",
						price: 231
					},
					{
						name: "Vanilla",
						price: 171
					},
					{
						name: "Rose",
						price: 171
					},
					{
						name: "Dry Fruit",
						price: 358
					},
					{
						name: "Special Dry Fruit",
						price: 380
					},
					{
						name: "Pineapple",
						price: 182
					},
					{
						name: "Extra ice-cream",
						price: 72,
						tag: "extra"
					}
				]
			},
			{
				name: "Soft Drinks",
				items: [
					{
						name: "Soda (Served in Glass)",
						price: 22
					},
					{
						name: "Cold Drink (Served in Glass)",
						price: 28
					},
					{
						name: "Mineral Water",
						price: 22
					},
					{
						name: "Fresh Lime Soda",
						price: 75
					}
				]
			}
		]
	},
	{
		id: "desserts",
		title: "Desserts",
		kicker: "Ice-cream, falooda, mastani & sweets",
		icon: "desserts",
		subsections: [
			{
				name: "Ice-Cream",
				items: [
					{
						name: "Vanilla",
						price: 66
					},
					{
						name: "Mango",
						price: 99
					},
					{
						name: "Chocolate",
						price: 99
					},
					{
						name: "Strawberry",
						price: 72
					},
					{
						name: "Kesar Pista",
						price: 105
					},
					{
						name: "Butter Scotch",
						price: 105
					},
					{
						name: "Cassata Frozen Dessert",
						price: null
					},
					{
						name: "Chocobar Frozen Dessert",
						price: null
					},
					{
						name: "Cornetto Frozen Dessert",
						price: null
					},
					{
						name: "Godbad",
						price: 341
					},
					{
						name: "Kailash Special Ice-Cream",
						price: 358,
						tag: "signature"
					}
				]
			},
			{
				name: "Falooda",
				items: [
					{
						name: "Royal Falooda",
						price: 303
					},
					{
						name: "Kesar Falooda",
						price: 325
					},
					{
						name: "Mango Falooda",
						price: 314
					},
					{
						name: "Kailash Special Falooda",
						price: 358,
						tag: "signature"
					}
				]
			},
			{
				name: "Mastani",
				items: [{
					name: "Dry Fruit Mastani",
					price: 352
				}, {
					name: "Mango Mastani",
					price: 369
				}]
			},
			{
				name: "Fruit Salads",
				items: [
					{
						name: "Fruit Salad",
						price: 154
					},
					{
						name: "Fruit Salad with Ice-cream",
						price: 182
					},
					{
						name: "Fruit Salad with Jelly",
						price: 165
					},
					{
						name: "Jelly with Ice-cream",
						price: 182
					}
				]
			},
			{
				name: "Sweets",
				items: [{
					name: "Rasgulla",
					price: 66
				}, {
					name: "Gulab Jammun",
					price: 61
				}]
			}
		]
	}
];
var QUICK_FINDS = [
	"Dosa",
	"Uttapa",
	"Paneer",
	"Dal",
	"Chinese",
	"Pizza",
	"Biryani",
	"Shake",
	"Ice-Cream",
	"Nan"
];
function chapterItemCount(chapter) {
	return chapter.subsections.reduce((sum, sub) => sum + sub.items.length, 0);
}
var TOTAL_DISHES = CHAPTERS.reduce((sum, ch) => sum + chapterItemCount(ch), 0);
function searchMenu(query) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	const hits = [];
	for (const chapter of CHAPTERS) for (const subsection of chapter.subsections) for (const item of subsection.items) if (`${item.name} ${subsection.name} ${chapter.title}`.toLowerCase().includes(q)) hits.push({
		chapter,
		subsection,
		item
	});
	return hits;
}
function groupHits(hits) {
	const map = /* @__PURE__ */ new Map();
	for (const hit of hits) {
		const key = `${hit.chapter.title} · ${hit.subsection.name}`;
		const list = map.get(key);
		if (list) list.push(hit);
		else map.set(key, [hit]);
	}
	return map;
}
var ICONS = {
	south: UtensilsCrossed,
	street: Store,
	punjabi: Flame,
	chinese: Soup,
	tandoor: Flame,
	rice: Wheat,
	breads: Wheat,
	sides: Salad,
	drinks: Coffee,
	desserts: IceCreamBowl
};
function MenuApp() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [activeId, setActiveId] = (0, import_react.useState)(CHAPTERS[0].id);
	const deckRef = (0, import_react.useRef)(null);
	const chipRefs = (0, import_react.useRef)({});
	const searching = query.trim().length > 0;
	const goTo = (0, import_react.useCallback)((id, behavior = "smooth") => {
		const deck = deckRef.current;
		const page = deck?.querySelector(`#chapter-${id}`);
		if (!deck || !page) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		page.scrollTop = 0;
		deck.scrollTo({
			left: page.offsetLeft,
			behavior: reduce ? "auto" : behavior
		});
		setActiveId(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const deck = deckRef.current;
		if (!deck || searching) return;
		const observer = new IntersectionObserver((entries) => {
			const id = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]?.target.getAttribute("data-chapter");
			if (id) setActiveId(id);
		}, {
			root: deck,
			threshold: .55
		});
		for (const page of deck.querySelectorAll("[data-chapter]")) observer.observe(page);
		return () => observer.disconnect();
	}, [searching]);
	(0, import_react.useEffect)(() => {
		chipRefs.current[activeId]?.scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	}, [activeId]);
	const activeIndex = CHAPTERS.findIndex((ch) => ch.id === activeId);
	const step = (0, import_react.useCallback)((dir) => {
		const next = CHAPTERS[activeIndex + dir];
		if (next) goTo(next.id);
	}, [activeIndex, goTo]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (searching) return;
			const target = event.target;
			if (target && ["INPUT", "TEXTAREA"].includes(target.tagName)) return;
			if (event.key === "ArrowRight") step(1);
			if (event.key === "ArrowLeft") step(-1);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [searching, step]);
	const hits = (0, import_react.useMemo)(() => searching ? searchMenu(query) : [], [query, searching]);
	const grouped = (0, import_react.useMemo)(() => groupHits(hits), [hits]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh max-w-full flex-col overflow-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "min-w-0 shrink-0 overflow-x-hidden border-b border-border bg-bg/90 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-11" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-script text-[1.85rem] leading-none text-primary",
								children: "Kailash"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 flex items-center gap-1.5 text-[0.65rem] font-medium tracking-[0.2em] text-muted uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-3 text-accent" }), "Veg Restaurant"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoDrawer, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-3 max-w-5xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "Find a dish — paneer, dosa, shake…",
								className: "pl-10 pr-11",
								"aria-label": "Search the menu"
							}),
							searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "absolute top-1/2 right-1.5 flex size-8 -translate-y-1/2 items-center justify-center rounded-md text-muted hover:bg-fg/5 hover:text-fg",
								onClick: () => setQuery(""),
								"aria-label": "Clear search",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							}) : null
						]
					}), !searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-nowrap gap-2 overflow-x-auto chip-rail pb-0.5",
						children: QUICK_FINDS.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setQuery(tag),
							className: "h-8 shrink-0 rounded-full bg-surface px-3 text-xs text-ink-soft shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]",
							children: tag
						}, tag))
					}) : null]
				}),
				!searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto mt-3 flex max-w-5xl flex-nowrap gap-2 overflow-x-auto chip-rail",
					"aria-label": "Menu sections",
					children: CHAPTERS.map((chapter) => {
						const Icon = ICONS[chapter.icon];
						const active = chapter.id === activeId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							ref: (node) => {
								chipRefs.current[chapter.id] = node;
							},
							onClick: () => goTo(chapter.id),
							className: cn("flex h-11 shrink-0 items-center gap-2 rounded-full px-3.5 text-sm font-medium transition-[background-color,color,transform] duration-150 active:scale-[0.96]", active ? "bg-primary text-primary-fg" : "bg-surface text-ink-soft shadow-[var(--shadow-border)]"),
							"aria-current": active ? "page" : void 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), chapter.title]
						}, chapter.id);
					})
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "relative min-h-0 flex-1 overflow-hidden",
			children: searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchPanel, {
				query,
				grouped,
				total: hits.length
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: deckRef,
				className: "menu-deck flex h-full min-h-0 w-full",
				"aria-label": "Swipe between kitchens",
				children: CHAPTERS.map((chapter, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterPage, {
					chapter,
					index
				}, chapter.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-[max(0.75rem,env(safe-area-inset-bottom))] flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-center gap-2 rounded-full bg-fg/90 px-2 py-1.5 text-primary-fg shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9 text-primary-fg hover:bg-primary-fg/10",
							onClick: () => step(-1),
							disabled: activeIndex <= 0,
							"aria-label": "Previous section",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "min-w-36 text-center text-xs tracking-wide",
							children: [
								String(activeIndex + 1).padStart(2, "0"),
								" / ",
								String(CHAPTERS.length).padStart(2, "0"),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block font-display text-sm tracking-normal",
									children: CHAPTERS[activeIndex]?.title
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9 text-primary-fg hover:bg-primary-fg/10",
							onClick: () => step(1),
							disabled: activeIndex >= CHAPTERS.length - 1,
							"aria-label": "Next section",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						})
					]
				})
			})] })
		})]
	});
}
function ChapterPage({ chapter, index }) {
	const Icon = ICONS[chapter.icon];
	const count = chapterItemCount(chapter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: `chapter-${chapter.id}`,
		"data-chapter": chapter.id,
		className: "menu-page flex h-full min-h-0 w-full shrink-0 basis-full flex-col overflow-y-auto px-4 pb-28",
		"aria-label": chapter.title,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-5xl pt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[0.7rem] font-medium tracking-[0.28em] text-muted uppercase",
							children: [
								roman(index + 1),
								" · ",
								count,
								" dishes"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl font-medium tracking-tight text-fg",
							children: chapter.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: chapter.kicker
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 flex size-11 items-center justify-center rounded-md bg-primary text-primary-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ornament, {}),
				chapter.id === "punjabi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LunchBoxCard, {}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-8",
					children: chapter.subsections.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl font-medium text-primary",
							children: sub.name
						}),
						sub.name === "Kailash Special 4 Feet Dosa" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 mb-2 text-sm text-muted",
							children: "House signature — extra-long dosa, made for sharing."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 grid grid-cols-1 md:grid-cols-2 md:gap-x-8",
							children: sub.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DishRow, { item }, `${sub.name}-${item.name}`))
						})
					] }, sub.name))
				})
			]
		})
	});
}
function DishRow({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-baseline gap-3 border-b border-border/80 py-2.5 last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1 text-pretty text-[0.95rem] leading-snug",
			children: [item.name, item.tag === "signature" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-2 align-middle text-[0.6rem] font-medium tracking-[0.16em] text-primary uppercase",
				children: "House"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 font-medium tabular-nums text-primary",
			children: formatPrice(item.price)
		})]
	});
}
function LunchBoxCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "mb-8 rounded-lg bg-primary px-4 py-4 text-primary-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest uppercase opacity-80",
				children: "Carry out"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-display text-2xl font-medium leading-tight",
				children: LUNCH_BOX.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm opacity-90",
				children: LUNCH_BOX.includes
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-medium tabular-nums",
				children: formatPrice(LUNCH_BOX.price)
			})
		]
	});
}
function SearchPanel({ query, grouped, total }) {
	if (total === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-full max-w-md flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-8 text-muted" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-2xl",
				children: "No dishes match"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Nothing in the Kailash menu for “",
					query,
					"”. Try dosa, paneer, or shake."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto px-4 pb-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					total,
					" ",
					total === 1 ? "dish" : "dishes",
					" for “",
					query,
					"”"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-col gap-8",
				children: [...grouped.entries()].map(([label, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl font-medium text-primary",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-1 md:grid-cols-2 md:gap-x-8",
					children: list.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DishRow, { item: hit.item }, `${hit.subsection.name}-${hit.item.name}`))
				})] }, label))
			})]
		})
	});
}
function InfoDrawer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Root, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Trigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "icon",
			"aria-label": "Restaurant information",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-40 bg-fg/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
		className: "fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-surface text-fg outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-y-auto px-5 pt-4 pb-[max(1.5rem,env(safe-area-inset-bottom))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoPlate, { className: "h-28 w-28" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "sr-only",
					children: "Kailash Veg Restaurant"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }),
							label: "Lunch",
							value: RESTAURANT.lunch
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }),
							label: "Dinner",
							value: RESTAURANT.dinner
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-4" }),
							label: "Kitchen",
							value: "Pure vegetarian"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ornament, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "flex flex-col gap-2.5 text-sm leading-relaxed text-ink-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.gst }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.oil }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.water }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.outside }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.smoking }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.marathi }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: RESTAURANT.msg })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 text-center text-xs text-muted",
					children: [
						TOTAL_DISHES,
						" dishes across ",
						CHAPTERS.length,
						" kitchens"
					]
				})
			]
		})]
	})] })] });
}
function InfoRow({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-md bg-bg px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-9 items-center justify-center rounded-sm bg-primary/10 text-primary",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.65rem] font-medium tracking-[0.18em] text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: value
		})] })]
	});
}
function Ornament() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-5 flex items-center gap-3",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rotate-45 bg-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
		]
	});
}
function roman(n) {
	const map = [
		[10, "X"],
		[9, "IX"],
		[5, "V"],
		[4, "IV"],
		[1, "I"]
	];
	let remaining = n;
	let out = "";
	for (const [value, glyph] of map) while (remaining >= value) {
		out += glyph;
		remaining -= value;
	}
	return out;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuApp, {});
}
//#endregion
export { Home as component };
