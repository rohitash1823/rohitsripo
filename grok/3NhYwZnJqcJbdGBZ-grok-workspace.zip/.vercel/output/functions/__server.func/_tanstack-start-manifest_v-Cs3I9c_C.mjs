//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cs3I9c_C.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bp2dNbCL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bp2dNbCL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CLeOpFGk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
