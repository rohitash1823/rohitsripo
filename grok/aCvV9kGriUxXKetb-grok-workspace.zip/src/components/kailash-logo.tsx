import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("shrink-0", className)}
      role="img"
      aria-label="Kailash"
    >
      <rect width="32" height="32" rx="6" fill="#8B1A1A" />
      <text
        x="16"
        y="23"
        textAnchor="middle"
        fill="#FBF6EC"
        fontFamily="Georgia, serif"
        fontSize="18"
        fontWeight="700"
      >
        K
      </text>
    </svg>
  );
}

export function LogoPlate({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 160 160"
      className={cn("shrink-0", className)}
      role="img"
      aria-label="Kailash Veg Restaurant"
    >
      <rect width="160" height="160" rx="8" fill="#8B1A1A" />
      <rect
        x="8"
        y="8"
        width="144"
        height="144"
        rx="4"
        fill="none"
        stroke="#F3E8D4"
        strokeWidth="1"
        opacity="0.28"
      />
      <g transform="translate(118 16)">
        <rect width="22" height="5" fill="#FF9933" />
        <rect y="5" width="22" height="5" fill="#FFFFFF" />
        <rect y="10" width="22" height="5" fill="#138808" />
        <circle cx="11" cy="7.5" r="1.6" fill="#000080" />
      </g>
      <text
        x="80"
        y="78"
        textAnchor="middle"
        fill="#FBF6EC"
        fontFamily="'Great Vibes', cursive"
        fontSize="48"
      >
        Kailash
      </text>
      <text
        x="80"
        y="104"
        textAnchor="middle"
        fill="#FBF6EC"
        fontFamily="'Cormorant Garamond', Georgia, serif"
        fontSize="11"
        letterSpacing="2.6"
      >
        VEG RESTAURANT
      </text>
      <text
        x="80"
        y="124"
        textAnchor="middle"
        fill="#F3E8D4"
        fontFamily="'Outfit', sans-serif"
        fontSize="7.5"
        opacity="0.85"
      >
        Unit of Hotel NANDANVAN Pvt. Ltd.
      </text>
    </svg>
  );
}
