"use client";

import {
  Coffee,
  ChevronLeft,
  ChevronRight,
  Clock,
  Flame,
  IceCreamBowl,
  Info,
  Leaf,
  Salad,
  Search,
  Soup,
  Store,
  UtensilsCrossed,
  Wheat,
  X,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Drawer } from "vaul";
import { LogoMark, LogoPlate } from "@/components/kailash-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  CHAPTERS,
  LUNCH_BOX,
  QUICK_FINDS,
  RESTAURANT,
  TOTAL_DISHES,
  chapterItemCount,
  groupHits,
  searchMenu,
  type Chapter,
  type MenuItem,
} from "@/lib/menu-data";
import { cn, formatPrice } from "@/lib/utils";

const ICONS: Record<Chapter["icon"], typeof Flame> = {
  south: UtensilsCrossed,
  street: Store,
  punjabi: Flame,
  chinese: Soup,
  tandoor: Flame,
  rice: Wheat,
  breads: Wheat,
  sides: Salad,
  drinks: Coffee,
  desserts: IceCreamBowl,
};

export function MenuApp() {
  const [query, setQuery] = useState("");
  const [activeId, setActiveId] = useState(CHAPTERS[0]!.id);
  const deckRef = useRef<HTMLDivElement>(null);
  const chipRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const searching = query.trim().length > 0;

  const goTo = useCallback((id: string, behavior: ScrollBehavior = "smooth") => {
    const deck = deckRef.current;
    const page = deck?.querySelector<HTMLElement>(`#chapter-${id}`);
    if (!deck || !page) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    page.scrollTop = 0;
    deck.scrollTo({
      left: page.offsetLeft,
      behavior: reduce ? "auto" : behavior,
    });
    setActiveId(id);
  }, []);

  useEffect(() => {
    const deck = deckRef.current;
    if (!deck || searching) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        const id = visible?.target.getAttribute("data-chapter");
        if (id) setActiveId(id);
      },
      { root: deck, threshold: 0.55 },
    );
    for (const page of deck.querySelectorAll("[data-chapter]")) {
      observer.observe(page);
    }
    return () => observer.disconnect();
  }, [searching]);

  useEffect(() => {
    chipRefs.current[activeId]?.scrollIntoView({
      behavior: "smooth",
      inline: "center",
      block: "nearest",
    });
  }, [activeId]);

  const activeIndex = CHAPTERS.findIndex((ch) => ch.id === activeId);

  const step = useCallback(
    (dir: -1 | 1) => {
      const next = CHAPTERS[activeIndex + dir];
      if (next) goTo(next.id);
    },
    [activeIndex, goTo],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (searching) return;
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA"].includes(target.tagName)) return;
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [searching, step]);

  const hits = useMemo(() => (searching ? searchMenu(query) : []), [query, searching]);
  const grouped = useMemo(() => groupHits(hits), [hits]);

  return (
    <div className="flex h-dvh max-w-full flex-col overflow-hidden bg-bg text-fg">
      <header className="min-w-0 shrink-0 overflow-x-hidden border-b border-border bg-bg/90 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 backdrop-blur-sm">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3">
          <LogoMark className="size-11" />
          <div className="min-w-0 flex-1">
            <p className="font-script text-[1.85rem] leading-none text-primary">Kailash</p>
            <p className="mt-0.5 flex items-center gap-1.5 text-[0.65rem] font-medium tracking-[0.2em] text-muted uppercase">
              <Leaf className="size-3 text-accent" />
              Veg Restaurant
            </p>
          </div>
          <InfoDrawer />
        </div>

        <div className="mx-auto mt-3 max-w-5xl">
          <label className="relative block">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Find a dish — paneer, dosa, shake…"
              className="pl-10 pr-11"
              aria-label="Search the menu"
            />
            {searching ? (
              <button
                type="button"
                className="absolute top-1/2 right-1.5 flex size-8 -translate-y-1/2 items-center justify-center rounded-md text-muted hover:bg-fg/5 hover:text-fg"
                onClick={() => setQuery("")}
                aria-label="Clear search"
              >
                <X className="size-4" />
              </button>
            ) : null}
          </label>
          {!searching ? (
            <div className="mt-2 flex flex-nowrap gap-2 overflow-x-auto chip-rail pb-0.5">
              {QUICK_FINDS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setQuery(tag)}
                  className="h-8 shrink-0 rounded-full bg-surface px-3 text-xs text-ink-soft shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]"
                >
                  {tag}
                </button>
              ))}
            </div>
          ) : null}
        </div>

        {!searching ? (
          <nav
            className="mx-auto mt-3 flex max-w-5xl flex-nowrap gap-2 overflow-x-auto chip-rail"
            aria-label="Menu sections"
          >
            {CHAPTERS.map((chapter) => {
              const Icon = ICONS[chapter.icon];
              const active = chapter.id === activeId;
              return (
                <button
                  key={chapter.id}
                  type="button"
                  ref={(node) => {
                    chipRefs.current[chapter.id] = node;
                  }}
                  onClick={() => goTo(chapter.id)}
                  className={cn(
                    "flex h-11 shrink-0 items-center gap-2 rounded-full px-3.5 text-sm font-medium transition-[background-color,color,transform] duration-150 active:scale-[0.96]",
                    active
                      ? "bg-primary text-primary-fg"
                      : "bg-surface text-ink-soft shadow-[var(--shadow-border)]",
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  <Icon className="size-4" />
                  {chapter.title}
                </button>
              );
            })}
          </nav>
        ) : null}
      </header>

      <main className="relative min-h-0 flex-1 overflow-hidden">
        {searching ? (
          <SearchPanel query={query} grouped={grouped} total={hits.length} />
        ) : (
          <>
            <div
              ref={deckRef}
              className="menu-deck flex h-full min-h-0 w-full"
              aria-label="Swipe between kitchens"
            >
              {CHAPTERS.map((chapter, index) => (
                <ChapterPage
                  key={chapter.id}
                  chapter={chapter}
                  index={index}
                />
              ))}
            </div>
            <div className="pointer-events-none absolute inset-x-0 bottom-[max(0.75rem,env(safe-area-inset-bottom))] flex justify-center">
              <div className="pointer-events-auto flex items-center gap-2 rounded-full bg-fg/90 px-2 py-1.5 text-primary-fg shadow-[var(--shadow-border)]">
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-9 text-primary-fg hover:bg-primary-fg/10"
                  onClick={() => step(-1)}
                  disabled={activeIndex <= 0}
                  aria-label="Previous section"
                >
                  <ChevronLeft className="size-5" />
                </Button>
                <p className="min-w-36 text-center text-xs tracking-wide">
                  {String(activeIndex + 1).padStart(2, "0")} / {String(CHAPTERS.length).padStart(2, "0")}
                  <span className="mt-0.5 block font-display text-sm tracking-normal">
                    {CHAPTERS[activeIndex]?.title}
                  </span>
                </p>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-9 text-primary-fg hover:bg-primary-fg/10"
                  onClick={() => step(1)}
                  disabled={activeIndex >= CHAPTERS.length - 1}
                  aria-label="Next section"
                >
                  <ChevronRight className="size-5" />
                </Button>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function ChapterPage({ chapter, index }: { chapter: Chapter; index: number }) {
  const Icon = ICONS[chapter.icon];
  const count = chapterItemCount(chapter);
  return (
    <section
      id={`chapter-${chapter.id}`}
      data-chapter={chapter.id}
      className="menu-page flex h-full min-h-0 w-full shrink-0 basis-full flex-col overflow-y-auto px-4 pb-28"
      aria-label={chapter.title}
    >
      <div className="mx-auto w-full max-w-5xl pt-5">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-[0.7rem] font-medium tracking-[0.28em] text-muted uppercase">
              {roman(index + 1)} · {count} dishes
            </p>
            <h2 className="font-display text-4xl font-medium tracking-tight text-fg">
              {chapter.title}
            </h2>
            <p className="mt-1 text-sm text-muted">{chapter.kicker}</p>
          </div>
          <span className="mb-1 flex size-11 items-center justify-center rounded-md bg-primary text-primary-fg">
            <Icon className="size-5" />
          </span>
        </div>
        <Ornament />
        {chapter.id === "punjabi" ? <LunchBoxCard /> : null}
        <div className="flex flex-col gap-8">
          {chapter.subsections.map((sub) => (
            <section key={sub.name}>
              <h3 className="font-display text-xl font-medium text-primary">{sub.name}</h3>
              {sub.name === "Kailash Special 4 Feet Dosa" ? (
                <p className="mt-1 mb-2 text-sm text-muted">
                  House signature — extra-long dosa, made for sharing.
                </p>
              ) : null}
              <ul className="mt-1 grid grid-cols-1 md:grid-cols-2 md:gap-x-8">
                {sub.items.map((item) => (
                  <DishRow key={`${sub.name}-${item.name}`} item={item} />
                ))}
              </ul>
            </section>
          ))}
        </div>
      </div>
    </section>
  );
}

function DishRow({ item }: { item: MenuItem }) {
  return (
    <li className="flex items-baseline gap-3 border-b border-border/80 py-2.5 last:border-b-0">
      <span className="min-w-0 flex-1 text-pretty text-[0.95rem] leading-snug">
        {item.name}
        {item.tag === "signature" ? (
          <span className="ml-2 align-middle text-[0.6rem] font-medium tracking-[0.16em] text-primary uppercase">
            House
          </span>
        ) : null}
      </span>
      <span className="shrink-0 font-medium tabular-nums text-primary">
        {formatPrice(item.price)}
      </span>
    </li>
  );
}

function LunchBoxCard() {
  return (
    <aside className="mb-8 rounded-lg bg-primary px-4 py-4 text-primary-fg">
      <p className="text-xs font-medium tracking-widest uppercase opacity-80">Carry out</p>
      <h3 className="mt-1 font-display text-2xl font-medium leading-tight">{LUNCH_BOX.name}</h3>
      <p className="mt-1 text-sm opacity-90">{LUNCH_BOX.includes}</p>
      <p className="mt-3 font-medium tabular-nums">{formatPrice(LUNCH_BOX.price)}</p>
    </aside>
  );
}

function SearchPanel({
  query,
  grouped,
  total,
}: {
  query: string;
  grouped: Map<string, ReturnType<typeof searchMenu>>;
  total: number;
}) {
  if (total === 0) {
    return (
      <div className="mx-auto flex h-full max-w-md flex-col items-center justify-center px-6 text-center">
        <Search className="size-8 text-muted" />
        <h2 className="mt-3 font-display text-2xl">No dishes match</h2>
        <p className="mt-1 text-sm text-muted">
          Nothing in the Kailash menu for “{query}”. Try dosa, paneer, or shake.
        </p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto px-4 pb-10">
      <div className="mx-auto max-w-5xl pt-4">
        <p className="text-sm text-muted">
          {total} {total === 1 ? "dish" : "dishes"} for “{query}”
        </p>
        <div className="mt-4 flex flex-col gap-8">
          {[...grouped.entries()].map(([label, list]) => (
            <section key={label}>
              <h3 className="font-display text-xl font-medium text-primary">{label}</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 md:gap-x-8">
                {list.map((hit) => (
                  <DishRow
                    key={`${hit.subsection.name}-${hit.item.name}`}
                    item={hit.item}
                  />
                ))}
              </ul>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}

function InfoDrawer() {
  return (
    <Drawer.Root>
      <Drawer.Trigger asChild>
        <Button variant="outline" size="icon" aria-label="Restaurant information">
          <Info className="size-5" />
        </Button>
      </Drawer.Trigger>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-40 bg-fg/40" />
        <Drawer.Content className="fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-surface text-fg outline-none">
          <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-border" />
          <div className="overflow-y-auto px-5 pt-4 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
            <div className="flex justify-center">
              <LogoPlate className="h-28 w-28" />
            </div>
            <Drawer.Title className="sr-only">Kailash Veg Restaurant</Drawer.Title>
            <div className="mt-5 grid gap-3">
              <InfoRow icon={<Clock className="size-4" />} label="Lunch" value={RESTAURANT.lunch} />
              <InfoRow icon={<Clock className="size-4" />} label="Dinner" value={RESTAURANT.dinner} />
              <InfoRow icon={<Leaf className="size-4" />} label="Kitchen" value="Pure vegetarian" />
            </div>
            <Ornament />
            <ul className="flex flex-col gap-2.5 text-sm leading-relaxed text-ink-soft">
              <li>{RESTAURANT.gst}</li>
              <li>{RESTAURANT.oil}</li>
              <li>{RESTAURANT.water}</li>
              <li>{RESTAURANT.outside}</li>
              <li>{RESTAURANT.smoking}</li>
              <li>{RESTAURANT.marathi}</li>
              <li>{RESTAURANT.msg}</li>
            </ul>
            <p className="mt-5 text-center text-xs text-muted">
              {TOTAL_DISHES} dishes across {CHAPTERS.length} kitchens
            </p>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

function InfoRow({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 rounded-md bg-bg px-3 py-3">
      <span className="flex size-9 items-center justify-center rounded-sm bg-primary/10 text-primary">
        {icon}
      </span>
      <div>
        <p className="text-[0.65rem] font-medium tracking-[0.18em] text-muted uppercase">{label}</p>
        <p className="text-sm">{value}</p>
      </div>
    </div>
  );
}

function Ornament() {
  return (
    <div className="my-5 flex items-center gap-3" aria-hidden="true">
      <span className="h-px flex-1 bg-border" />
      <span className="size-1.5 rotate-45 bg-primary" />
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}

function roman(n: number): string {
  const map: [number, string][] = [
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"],
  ];
  let remaining = n;
  let out = "";
  for (const [value, glyph] of map) {
    while (remaining >= value) {
      out += glyph;
      remaining -= value;
    }
  }
  return out;
}
