export type MenuItem = {
  name: string;
  price: number | null;
  tag?: "signature" | "extra";
};

export type Subsection = {
  name: string;
  items: MenuItem[];
};

export type Chapter = {
  id: string;
  title: string;
  kicker: string;
  icon: "south" | "street" | "punjabi" | "chinese" | "tandoor" | "rice" | "breads" | "sides" | "drinks" | "desserts";
  subsections: Subsection[];
};

export const RESTAURANT = {
  name: "Kailash",
  tagline: "VEG RESTAURANT",
  unit: "Unit of Hotel NANDANVAN Pvt. Ltd.",
  gst: "9% GST Extra On Bill Amount",
  lunch: "11am – 4pm",
  dinner: "7pm – 11pm",
  oil: "All food are prepared in Sunflower Refine Oil & Pure Ghee",
  water: "Safe Drinking (Potable) Water is available free of charge",
  outside: "Outside Food Not Allowed",
  smoking: "No Smoking · Take Care of your belongings",
  marathi:
    "आम्ही आमच्या संस्थामधे पीज गॅसलां वापरत नाही. आम्ही तुपापासून बनवलेल्या मसाले फक्त वापर करतो.",
  msg: "Ajinomoto (MSG) is used in some cuisine. Not recommended for infants below 12 months and pregnant women.",
} as const;

export const LUNCH_BOX = {
  name: "Carry Lunch Box",
  price: 320,
  includes: "2 Veg. 3 Chapati, Rice, Sweet, 1 Dal, 1 Papad",
} as const;

export const CHAPTERS: Chapter[] = [
  {
    id: "south-indian",
    title: "South Indian",
    kicker: "Snacks, uttapa & dosa",
    icon: "south",
    subsections: [
      {
        name: "South Indian Snacks",
        items: [
          { name: "Upama", price: 66 },
          { name: "Sheera", price: 77 },
          { name: "Steam Idli", price: 66 },
          { name: "Fried Idli", price: 83 },
          { name: "Dahi Idli", price: 109 },
          { name: "Butter Idli", price: 97 },
          { name: "Idli Vada", price: 88 },
          { name: "Medu Vada", price: 88 },
          { name: "Dahi Vada", price: 109 },
          { name: "Cutlet", price: 83 },
          { name: "Cutlet With Chole", price: 143 },
          { name: "Finger Chips", price: 143 },
          { name: "Sabudana Vada", price: 88 },
          { name: "Potato Vada", price: 66 },
          { name: "Sweet Kachori", price: 109 },
          { name: "Sabudana Khichdi", price: 105 },
        ],
      },
      {
        name: "Uttapa",
        items: [
          { name: "Onion Uttapa", price: 99 },
          { name: "Coconut Uttapa", price: 99 },
          { name: "Tomato Uttapa", price: 99 },
          { name: "Masala Uttapa", price: 132 },
          { name: "Special Uttapa", price: 149 },
          { name: "Cheese Uttapa", price: 160 },
          { name: "Tomato Omlet", price: 109 },
          { name: "Banana Uttapa", price: 109 },
          { name: "Butter Onion Uttapa", price: 116 },
          { name: "Butter Plain Uttapa", price: 105 },
          { name: "Tomato Onion Uttapa", price: 116 },
          { name: "Spring Masala Uttapa", price: 149 },
          { name: "Veg. Uttapa", price: 149 },
        ],
      },
      {
        name: "Kailash Special 4 Feet Dosa",
        items: [
          { name: "Sada Dosa", price: 429, tag: "signature" },
          { name: "Masala Dosa", price: 468, tag: "signature" },
        ],
      },
      {
        name: "Dosa",
        items: [
          { name: "Sada Dosa", price: 88 },
          { name: "Masala Dosa", price: 103 },
          { name: "Palak Sada Dosa", price: 105 },
          { name: "Palak Masala", price: 127 },
          { name: "Mysore Sada Dosa", price: 121 },
          { name: "Mysore Masala Dosa", price: 138 },
          { name: "Kailash Special Dosa", price: 149, tag: "signature" },
          { name: "Cheese Masala Dosa", price: 182 },
          { name: "Set Dosa", price: 121 },
          { name: "Dosa Tokri", price: 358 },
          { name: "Cheese Sada Dosa", price: 149 },
          { name: "Onion Rawa Dosa", price: 127 },
          { name: "Onion Rawa Sada Dosa", price: 116 },
          { name: "Onion Rawa Masala Dosa", price: 127 },
          { name: "Rawa Masala Dosa", price: 116 },
          { name: "Rawa Sada Dosa", price: 116 },
          { name: "Butter Sada Dosa", price: 99 },
          { name: "Butter Masala Dosa", price: 127 },
          { name: "Extra Sambar / Chutney", price: 11, tag: "extra" },
          { name: "Extra Aloo Bhaji", price: 11, tag: "extra" },
          { name: "Extra Cheese", price: 66, tag: "extra" },
        ],
      },
      {
        name: "Special Dosa",
        items: [
          { name: "Paneer Chilli Dosa", price: 292 },
          { name: "Veg. Masala Dosa", price: 182 },
          { name: "Paneer Schezwan Dosa", price: 303 },
          { name: "Veg. Noodle Dosa", price: 231 },
          { name: "Veg. Schez. Noodles Dosa", price: 248 },
          { name: "Paneer Chilli Rawa Dosa", price: 303 },
          { name: "Paneer Schez. Rawa Dosa", price: 314 },
          { name: "Veg. Noodle Rawa Dosa", price: 292 },
          { name: "Scz. Noodle Rawa Dosa", price: 314 },
          { name: "Spring Dosa", price: 160 },
        ],
      },
    ],
  },
  {
    id: "street",
    title: "Street Favourites",
    kicker: "Chat, sandwich, pav bhaji & pizza",
    icon: "street",
    subsections: [
      {
        name: "Chat",
        items: [
          { name: "Pani Puri", price: 109 },
          { name: "Bombay Bhel", price: 109 },
          { name: "Special Bhel", price: 121 },
          { name: "Shev Puri", price: 121 },
          { name: "Dahi Shev Puri", price: 132 },
        ],
      },
      {
        name: "Sandwich",
        items: [
          { name: "Veg Sandwich", price: 94 },
          { name: "Cheese Sandwich", price: 116 },
          { name: "Cheese Veg Sandwich", price: 138 },
          { name: "Veg. Toast Sandwich", price: 149 },
          { name: "Veg Grill Sandwich", price: 160 },
          { name: "Veg Cheese Grill Sandwich", price: 187 },
          { name: "Cheese Grill Sandwich", price: 176 },
          { name: "Cheese Chilli Grill Sandwich", price: 215 },
          { name: "Jam Sandwich", price: 77 },
          { name: "Bread Butter Toast", price: 88 },
          { name: "Butter Cheese Toast", price: 138 },
          { name: "Chutney Sandwich", price: 83 },
          { name: "Tomato Omelet Toast S/w", price: 160 },
          { name: "Butter Jam", price: 99 },
        ],
      },
      {
        name: "Pav Bhaji",
        items: [
          { name: "Sada Pav Bhaji", price: 121 },
          { name: "Bombay Pav Bhaji", price: 149 },
          { name: "Jain Pav Bhaji", price: 121 },
          { name: "Paneer Pav Bhaji", price: 149 },
          { name: "Special Pav Bhaji", price: 160 },
          { name: "Khada Pav Bhaji", price: 143 },
          { name: "Cheese Pav Bhaji", price: 182 },
          { name: "Extra Pav with Butter (2 pcs)", price: 28, tag: "extra" },
          { name: "Masala Pav (2 pcs)", price: 132 },
          { name: "Extra Bhaji", price: 99, tag: "extra" },
          { name: "Tawa Pulav", price: 231 },
        ],
      },
      {
        name: "Pizza",
        items: [
          { name: "Cheese Pizza", price: 270 },
          { name: "Capsicum Pizza", price: 270 },
          { name: "Tomato Pizza", price: 270 },
          { name: "Mix Veg. Pizza", price: 297 },
          { name: "Cheese Paneer Pizza", price: 308 },
          { name: "Veg. Special Pizza", price: 319 },
        ],
      },
    ],
  },
  {
    id: "punjabi",
    title: "Punjabi Kitchen",
    kicker: "Gravies, paneer, dal & kofta",
    icon: "punjabi",
    subsections: [
      {
        name: "Paneer",
        items: [
          { name: "Paneer Butter Masala", price: 314 },
          { name: "Paneer Tikka Masala", price: 347 },
          { name: "Mutter Paneer", price: 303 },
          { name: "Paneer Bhurji", price: 292 },
          { name: "Paneer Tikka Lababdar", price: 358 },
          { name: "Paneer Lasuni M/S", price: 325 },
          { name: "Paneer Maratha", price: 314 },
          { name: "Paneer Pasanda", price: 347 },
          { name: "Paneer Shahi Kurma", price: 314 },
          { name: "Kadhai Paneer", price: 341 },
          { name: "Paneer Tawa Masala", price: 314 },
          { name: "Paneer Handi", price: 341 },
          { name: "Paneer Palak", price: 292 },
          { name: "Paneer Kheema Masala", price: 325 },
          { name: "Kaju Paneer Masala", price: 347 },
        ],
      },
      {
        name: "Dal",
        items: [
          { name: "Chole Batura", price: 231 },
          { name: "Extra Batura", price: 72, tag: "extra" },
          { name: "Dal Fry", price: 176 },
          { name: "Dal Tadka", price: 193 },
          { name: "Dal Kolhapuri", price: 193 },
          { name: "Dal Makhani", price: 270 },
          { name: "Dal Jaffrezi", price: 308 },
          { name: "Rajma Masala", price: 264 },
        ],
      },
      {
        name: "Kofta",
        items: [
          { name: "Malai Kofta", price: 308 },
          { name: "Cheese Kofta", price: 352 },
          { name: "Veg. Kofta", price: 303 },
          { name: "Veg. Kashmiri Kofta", price: 325 },
        ],
      },
      {
        name: "Palak, Methi & Kaju",
        items: [
          { name: "Plain Palak", price: 231 },
          { name: "Mushroom Palak", price: 325 },
          { name: "Aloo Palak", price: 231 },
          { name: "Methi Mutter Malai", price: 319 },
          { name: "Aloo Methi", price: 215 },
          { name: "Methi Lasuni", price: 226 },
          { name: "Methi Lasuni Masala", price: 270 },
          { name: "Kaju Mutter", price: 336 },
          { name: "Kaju Curry", price: 358 },
        ],
      },
      {
        name: "Vegetable Gravies",
        items: [
          { name: "Green Peas Aloo Masala", price: 231 },
          { name: "Green Peas Masala", price: 231 },
          { name: "Mushroom Masala", price: 314 },
          { name: "Babycorn Masala", price: 314 },
          { name: "Veg. Maratha", price: 303 },
          { name: "Jeera Aloo", price: 171 },
          { name: "Chana Masala", price: 231 },
          { name: "Baigan Masala", price: 231 },
          { name: "Baigan Bharta", price: 231 },
          { name: "Drumstick Masala", price: 281 },
          { name: "Shevbhaji Masala", price: 231 },
          { name: "Bhendi Masala fry", price: 231 },
          { name: "Karela Masala", price: 231 },
          { name: "Capsicum Masala", price: 226 },
          { name: "Stuff Capsicum", price: 226 },
          { name: "Tomato Bharta", price: 215 },
          { name: "Stuff Tomato", price: 215 },
          { name: "Veg Handi", price: 314 },
          { name: "Veg. Kadhai", price: 314 },
          { name: "Veg. Tawa", price: 308 },
          { name: "Veg. Bhoona", price: 308 },
          { name: "Veg. Maharaja", price: 325 },
          { name: "Veg Makhanwala", price: 292 },
          { name: "Veg. Kabab Curry", price: 308 },
          { name: "Veg. Aloo Gobi", price: 231 },
          { name: "Veg. Liver Masala", price: 303 },
          { name: "Veg. Angoori", price: 308 },
          { name: "Veg. Jaipuri", price: 308 },
          { name: "Navratan Kurma", price: 325 },
          { name: "Dum Aloo Kashmiri", price: 297 },
          { name: "Veg. Chatpata", price: 297 },
          { name: "Kailash Special Veg", price: 352, tag: "signature" },
          { name: "Baigan Tikka", price: 281 },
          { name: "Cheese Angoori", price: 347 },
          { name: "Veg Kheema Masala", price: 281 },
          { name: "Veg. Kolhapuri", price: 314 },
          { name: "Veg. Pattyala", price: 325 },
          { name: "Veg. Dhwani Handi", price: 308 },
          { name: "Hyderabadi Kurma", price: 308 },
          { name: "Veg Kurma", price: 308 },
          { name: "Veg. Afghani", price: 341 },
          { name: "Mix Vegitable", price: 286 },
          { name: "Mushroom Tikka Masala", price: 352 },
          { name: "Mushroom Kolhapuri", price: 361 },
        ],
      },
    ],
  },
  {
    id: "chinese",
    title: "Chinese",
    kicker: "Soups, starters, gravy & noodles",
    icon: "chinese",
    subsections: [
      {
        name: "Chinese Soups",
        items: [
          { name: "Sweet Corn Plain Soup", price: 116 },
          { name: "Sweet Corn Veg. Soup", price: 132 },
          { name: "Hot & Sour Soup", price: 132 },
          { name: "Manchow Soup", price: 143 },
          { name: "Mushroom Soup", price: 154 },
          { name: "Veg. Noodle Soup", price: 154 },
          { name: "Green Peas Soup", price: 138 },
          { name: "Cream Of Palak Soup", price: 149 },
          { name: "Tomato Soup", price: 116 },
          { name: "Cream Of Veg. Soup", price: 149 },
          { name: "Veg. Clear Soup", price: 94 },
        ],
      },
      {
        name: "Starters",
        items: [
          { name: "Chinese Bhel", price: 204 },
          { name: "Veg. Spring Roll", price: 281 },
          { name: "Veg. Lolly pop", price: 281 },
          { name: "Veg. Ball Schezwan Dry", price: 303 },
          { name: "Cheese Ball Schezwan", price: 352 },
          { name: "Veg. Gold Coin", price: 215 },
          { name: "Veg. Gold Finger", price: 215 },
          { name: "Veg. Crispy Dry", price: 325 },
          { name: "Veg. Prem Roll", price: 341 },
          { name: "Baby Corn Chilli", price: 325 },
          { name: "Paneer Chilli Dry", price: 325 },
          { name: "Paneer Kentucky", price: 325 },
          { name: "Gobi Kentucky", price: 314 },
          { name: "Baby Corn Kentucky", price: 341 },
          { name: "Mushroom Kentucky", price: 363 },
          { name: "Cheese Pakoda", price: 363 },
          { name: "Paneer Pakoda", price: 308 },
        ],
      },
      {
        name: "Manchurian",
        items: [
          { name: "Veg. Manchurian", price: 281 },
          { name: "Veg. Garlic", price: 292 },
          { name: "Veg. Schezwan", price: 292 },
          { name: "Mushroom Manchurian", price: 341 },
          { name: "Paneer Manchurian", price: 325 },
          { name: "Idli Manchurian", price: 286 },
          { name: "Gobi Manchurian", price: 281 },
        ],
      },
      {
        name: "Chillis",
        items: [
          { name: "Paneer Chilli", price: 325 },
          { name: "Veg. Chilli", price: 303 },
          { name: "Mushroom Chilli", price: 341 },
          { name: "Idli Chilli", price: 308 },
          { name: "Paneer 65", price: 325 },
          { name: "Veg. 65", price: 308 },
          { name: "Veg. Hong Kong", price: 308 },
          { name: "Paneer Hong Kong", price: 341 },
        ],
      },
      {
        name: "Rice & Noodles",
        items: [
          { name: "Veg. Fried Rice", price: 270 },
          { name: "Mushroom Fried Rice", price: 303 },
          { name: "Onion Fried Rice", price: 259 },
          { name: "Jeera Fried Rice", price: 242 },
          { name: "Singapore Fried Rice", price: 303 },
          { name: "Schezwan Fried Rice", price: 314 },
          { name: "Triple Schezwan Fried Rice", price: 341 },
          { name: "Veg. Noodles", price: 237 },
          { name: "Noodle Fried Rice", price: 308 },
          { name: "Schezwan Noodle Fried Rice", price: 325 },
          { name: "Veg. Schezwan Noodle", price: 292 },
          { name: "Veg. Singapore Noodle", price: 292 },
          { name: "Veg. American Choupsay", price: 314 },
        ],
      },
    ],
  },
  {
    id: "tandoor",
    title: "Tandoor",
    kicker: "Kabab & tikka",
    icon: "tandoor",
    subsections: [
      {
        name: "Kabab",
        items: [
          { name: "Paneer Tikka", price: 352 },
          { name: "Dry Tandoori Gobi", price: 325 },
          { name: "Veg. Sheekh Kabab", price: 325 },
          { name: "Veg. Harabhara Kabab", price: 259 },
          { name: "Mushroom Tikka", price: 363 },
        ],
      },
    ],
  },
  {
    id: "rice",
    title: "Rice",
    kicker: "Biryani, pulav & khichdi",
    icon: "rice",
    subsections: [
      {
        name: "Rice",
        items: [
          { name: "Veg. Biryani", price: 231 },
          { name: "Paneer Tikka Biryani", price: 259 },
          { name: "Veg. Handi Biryani", price: 248 },
          { name: "Veg. Hyderabadi Biryani", price: 237 },
          { name: "Veg. Dum Biryani", price: 281 },
          { name: "Veg. Pulav", price: 215 },
          { name: "Steam Rice", price: 171 },
          { name: "Jeera Rice", price: 182 },
          { name: "Kashmiri Pulav", price: 292 },
          { name: "Green Peas Pulav", price: 215 },
          { name: "Palak Rice", price: 215 },
          { name: "Curd Rice", price: 215 },
          { name: "Onion Rice", price: 215 },
          { name: "Dal Khichdi", price: 204 },
          { name: "Tadka Dal Khichdi", price: 215 },
          { name: "Paneer Pulav", price: 237 },
          { name: "Cheese Pulav", price: 303 },
        ],
      },
    ],
  },
  {
    id: "breads",
    title: "Breads",
    kicker: "Roti, nan, paratha & kulcha",
    icon: "breads",
    subsections: [
      {
        name: "Roti",
        items: [
          { name: "Plain Roti", price: 24 },
          { name: "Butter Roti", price: 31 },
          { name: "Wheat Roti", price: 33 },
          { name: "Butter Wheat Roti", price: 39 },
          { name: "Methi Roti", price: 39 },
          { name: "Nan", price: 50 },
          { name: "Butter Nan", price: 61 },
          { name: "Plain Paratha", price: 50 },
          { name: "Butter Paratha", price: 61 },
          { name: "Paneer Paratha", price: 171 },
          { name: "Cheese Paratha", price: 209 },
          { name: "Kulcha", price: 61 },
          { name: "Butter Kulcha", price: 72 },
          { name: "PARATHA (Methi, Aloo, Gobi)", price: 160 },
          { name: "Kashmiri Nan", price: 209 },
          { name: "Garlic Nan", price: 94 },
          { name: "Chapati", price: 18 },
          { name: "Basket Roti", price: 439 },
        ],
      },
    ],
  },
  {
    id: "sides",
    title: "Sides",
    kicker: "Salad, papad & raita",
    icon: "sides",
    subsections: [
      {
        name: "Salad",
        items: [
          { name: "Green Salad", price: 105 },
          { name: "Tomato Salad", price: 88 },
          { name: "Crispy Noodle Salad", price: 209 },
          { name: "Chee. Cherry Pineapple Salad", price: 308 },
        ],
      },
      {
        name: "Papad",
        items: [
          { name: "Roasted Papad", price: 22 },
          { name: "Fry Papad", price: 33 },
          { name: "Masala Papad", price: 50 },
        ],
      },
      {
        name: "Raita",
        items: [
          { name: "Mix Raita", price: 121 },
          { name: "Fruit Raita", price: 132 },
          { name: "Pine Apple Raita", price: 132 },
          { name: "Tomato Raita", price: 116 },
          { name: "Onion Raita", price: 116 },
          { name: "Boondi Raita", price: 121 },
          { name: "Aloo Raita", price: 116 },
          { name: "Plain Raita", price: 105 },
        ],
      },
    ],
  },
  {
    id: "drinks",
    title: "Drinks",
    kicker: "Hot drinks, juice, lassi & shakes",
    icon: "drinks",
    subsections: [
      {
        name: "Hot Drink",
        items: [
          { name: "Tea", price: 33 },
          { name: "Filter Coffee", price: 50 },
          { name: "Nes Coffee", price: 55 },
          { name: "Bournvita", price: 83 },
          { name: "Hot Chocolate", price: 83 },
        ],
      },
      {
        name: "Juice",
        items: [
          { name: "Mosambi (Sweet-Lime)", price: 105 },
          { name: "Orange Juice", price: 105 },
          { name: "Ganga Jamuna", price: 105 },
          { name: "Mars Mari", price: 105 },
          { name: "Cocktail Juice", price: 105 },
          { name: "Pineapple Juice", price: 105 },
          { name: "Grape Juice", price: 138 },
          { name: "Mango Juice", price: 116 },
          { name: "Fresh Lime", price: 61 },
          { name: "Watermelon", price: 105 },
        ],
      },
      {
        name: "Lassi",
        items: [
          { name: "Sweet Lassi", price: 109 },
          { name: "Mango Lassi", price: 138 },
          { name: "Special Lassi", price: 182 },
          { name: "Salted Lassi", price: 109 },
          { name: "Butter Milk", price: 39 },
        ],
      },
      {
        name: "Milk Shake",
        items: [
          { name: "Apple Shake", price: 215 },
          { name: "Chikoo Shake", price: 204 },
          { name: "Anjeer Shake", price: 237 },
          { name: "Mix Shake", price: 198 },
          { name: "Cold Coffee", price: 176 },
          { name: "Chocolate Shake", price: 176 },
          { name: "Banana Shake", price: 176 },
          { name: "Strawberry Shake", price: 204 },
          { name: "Mango", price: 231 },
          { name: "Vanilla", price: 171 },
          { name: "Rose", price: 171 },
          { name: "Dry Fruit", price: 358 },
          { name: "Special Dry Fruit", price: 380 },
          { name: "Pineapple", price: 182 },
          { name: "Extra ice-cream", price: 72, tag: "extra" },
        ],
      },
      {
        name: "Soft Drinks",
        items: [
          { name: "Soda (Served in Glass)", price: 22 },
          { name: "Cold Drink (Served in Glass)", price: 28 },
          { name: "Mineral Water", price: 22 },
          { name: "Fresh Lime Soda", price: 75 },
        ],
      },
    ],
  },
  {
    id: "desserts",
    title: "Desserts",
    kicker: "Ice-cream, falooda, mastani & sweets",
    icon: "desserts",
    subsections: [
      {
        name: "Ice-Cream",
        items: [
          { name: "Vanilla", price: 66 },
          { name: "Mango", price: 99 },
          { name: "Chocolate", price: 99 },
          { name: "Strawberry", price: 72 },
          { name: "Kesar Pista", price: 105 },
          { name: "Butter Scotch", price: 105 },
          { name: "Cassata Frozen Dessert", price: null },
          { name: "Chocobar Frozen Dessert", price: null },
          { name: "Cornetto Frozen Dessert", price: null },
          { name: "Godbad", price: 341 },
          { name: "Kailash Special Ice-Cream", price: 358, tag: "signature" },
        ],
      },
      {
        name: "Falooda",
        items: [
          { name: "Royal Falooda", price: 303 },
          { name: "Kesar Falooda", price: 325 },
          { name: "Mango Falooda", price: 314 },
          { name: "Kailash Special Falooda", price: 358, tag: "signature" },
        ],
      },
      {
        name: "Mastani",
        items: [
          { name: "Dry Fruit Mastani", price: 352 },
          { name: "Mango Mastani", price: 369 },
        ],
      },
      {
        name: "Fruit Salads",
        items: [
          { name: "Fruit Salad", price: 154 },
          { name: "Fruit Salad with Ice-cream", price: 182 },
          { name: "Fruit Salad with Jelly", price: 165 },
          { name: "Jelly with Ice-cream", price: 182 },
        ],
      },
      {
        name: "Sweets",
        items: [
          { name: "Rasgulla", price: 66 },
          { name: "Gulab Jammun", price: 61 },
        ],
      },
    ],
  },
];

export const QUICK_FINDS = [
  "Dosa",
  "Uttapa",
  "Paneer",
  "Dal",
  "Chinese",
  "Pizza",
  "Biryani",
  "Shake",
  "Ice-Cream",
  "Nan",
] as const;

export function chapterItemCount(chapter: Chapter): number {
  return chapter.subsections.reduce((sum, sub) => sum + sub.items.length, 0);
}

export const TOTAL_DISHES = CHAPTERS.reduce((sum, ch) => sum + chapterItemCount(ch), 0);

export type SearchHit = {
  chapter: Chapter;
  subsection: Subsection;
  item: MenuItem;
};

export function searchMenu(query: string): SearchHit[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const hits: SearchHit[] = [];
  for (const chapter of CHAPTERS) {
    for (const subsection of chapter.subsections) {
      for (const item of subsection.items) {
        const hay = `${item.name} ${subsection.name} ${chapter.title}`.toLowerCase();
        if (hay.includes(q)) hits.push({ chapter, subsection, item });
      }
    }
  }
  return hits;
}

export function groupHits(hits: SearchHit[]): Map<string, SearchHit[]> {
  const map = new Map<string, SearchHit[]>();
  for (const hit of hits) {
    const key = `${hit.chapter.title} · ${hit.subsection.name}`;
    const list = map.get(key);
    if (list) list.push(hit);
    else map.set(key, [hit]);
  }
  return map;
}
